package auto.spring1;

public class student {
private adr address;

public student() {
	super();
	// TODO Auto-generated constructor stub
}

public student(adr address) {
	super();
	this.address = address;
System.out.print("constructor called"+"");
}

@Override
public String toString() {
	return "student [address=" + address + ", getAddress()=" + getAddress() + ", getClass()=" + getClass()
			+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
}

public adr getAddress() {
	return address;
}

public void setAddress(adr address) {
	this.address = address;
}
}
